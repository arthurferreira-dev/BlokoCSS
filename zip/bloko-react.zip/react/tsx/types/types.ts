export type ModalType = {
    
}